//
//  User.swift
//  ToDoList
//
//  Created by user242497 on 9/5/23.
//

import Foundation

struct User: Codable {
    let id: String
    let name: String
    let email: String
    let joined: TimeInterval
}
